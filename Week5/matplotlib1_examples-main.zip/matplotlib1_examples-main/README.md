# matplotlib1_examples
This script includes several basic examples for using matplotlib to plot data
